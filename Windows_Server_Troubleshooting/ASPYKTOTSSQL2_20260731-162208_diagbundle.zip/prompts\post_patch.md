# Post-patch investigation

Use when `manifest.collection.scenario_hint = post_patch`, or when the
operator says "after patching" / "since the last reboot".

## Orientation

1. `summary/patching.json` -- what was offered, installed, or failed in the
   last 24 hours (or the `WindowHours` value in `manifest.time_window`).
2. `summary/inventory.json` -> `last_boot_utc` -- did the box reboot? When?
3. `summary/events_summary.json` -> System channel -> `boot_markers` --
   ordered list of 6005, 6006, 6008, 1074 in the window.

## Patterns to look for

### A patch failed

- `patching.json` -> `update_history` -> entries with `operation = Install`
  and `result_code != 2` (2 = Succeeded). `hresult` is the Windows error
  code in hex.
- `raw/eventlogs/Setup.evtx` -- correlated install or rollback events
  around the failed update's `date_utc`.
- `raw/cbs/CBS.log` -- search for the package name. CBS errors include
  `STATUS_CANNOT_DELETE`, `ERROR_SXS_ASSEMBLY_MISSING`,
  `CBS_E_INVALID_PACKAGE`.
- `raw/cbs/CbsPersist_*.log` -- prior session logs. The 50MB tail is
  applied; older detail may be off the front of the file.

### A patch installed but the box is now misbehaving

- `summary/baseline_diff.json` (if present) -- services, scheduled tasks,
  or autoruns that changed since the last baseline.
- `summary/services.json` -> `stopped_auto_names` -- services configured
  Auto-start that are not running.
- `summary/events_summary.json` -> Application and System channels -> top
  events. New errors appearing only since the latest `boot_markers` entry
  are highly suspicious.
- `summary/ad_context.json` -> `w32tm_status` -- patches occasionally
  break time sync; verify the host still has a synced peer.

### A reboot is still pending

- `summary/patching.json` -> `pending_reboot` block. Each flag has a
  distinct cause:
  - `cbs_reboot_pending` -- Windows component servicing finished a stage
    that requires a reboot.
  - `wu_reboot_required` -- Windows Update Auto Update has staged a
    reboot.
  - `pending_file_rename` -- file replacements queued at next boot via
    Session Manager.
  - `sccm_pending_reboot` -- the SCCM client says reboot pending. Trusts
    `root\ccm\ClientSDK CCM_ClientUtilities.DetermineIfRebootPending`
    when available; falls back to a registry breadcrumb that can give a
    false positive on some boxes (this collector prefers the WMI path).

Name the flag(s) when reporting to the operator.

## Drill-down hops

1. From a suspicious EventID in `events_summary.json` -> `wevtutil qe` on
   the raw EVTX (see README.md "Drill-down recipes").
2. From a CBS reference -> grep `raw/cbs/CBS.log` for the package or
   session GUID.
3. From a Windows Update entry -> `Get-WindowsUpdateLog` on
   `raw/windowsupdate/*.etl`.
4. From a service that stopped auto-starting -> `services.json` row for
   `path_name` and `start_name`; cross-check `events_summary.json`
   Application channel for crash signatures of the binary.
