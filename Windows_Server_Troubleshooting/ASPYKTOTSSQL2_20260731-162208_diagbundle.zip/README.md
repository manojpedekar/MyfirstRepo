# DiagBundle

This ZIP is a one-shot Windows Server diagnostic bundle produced by the
DiagBundle PowerShell module. It captures a snapshot of one host at one point
in time, intended for AI-assisted analysis or human triage.

Schema version: see `manifest.json` -> `schema_version`. Treat the manifest
shape as a stability commitment; major changes bump the version.

## Read in this order

1. **manifest.json** -- root inventory. Lists every artifact with path,
   category, type (`derived` or `raw`), schema_version, sha256, size, and a
   one-line description. Also carries `collection_errors[]` -- the second
   most important field after `artifacts[]`.
2. **summary/*.json** -- pre-aggregated, AI-friendly views per category.
   Read all of these next. Small, structured, opinionated.
3. **raw/** -- forensic artifacts referenced by summaries. Open only when a
   summary points at something worth investigating deeper.
4. **prompts/** -- short investigation scaffolds aligned to the four
   `Scenario` values. Use the one that matches `manifest.collection.scenario_hint`,
   or pick by symptom.

## Bundle layout

```
manifest.json           # entry point
summary/                # AI-friendly aggregated JSON
  inventory.json
  drivers.json
  patching.json
  events_summary.json
  processes.json
  services.json
  perf_summary.json     # absent if the Performance collector was skipped
  storage.json
  network.json
  ad_context.json
  crashes_wer.json
  roles_apps.json
  baseline_diff.json    # only if a baseline existed
raw/                    # forensic preservation, untransformed
  eventlogs/*.evtx
  cbs/CBS.log + CbsPersist_*.log
  windowsupdate/*.etl
  drivers/pnputil_enum_drivers.txt
  perf/snapshot.blg
  wer/, dumps/, netsh/, gpo/, registry/, tasks/, role_specific/
transcript/
  collector.log         # per-event JSON lines from the collector
  transcript.txt        # PowerShell Start-Transcript output
prompts/                # investigation scaffolds
  post_patch.md
  performance_regression.md
  general_triage.md
  forensic_preservation.md
README.md               # this file
checksums.txt           # SHA256 of every other file
```

## Where to start by question

- "What changed recently?" -> `summary/patching.json` and `summary/baseline_diff.json`.
- "Why is the box slow?" -> `summary/perf_summary.json` and `summary/processes.json`.
- "What broke last patch cycle?" -> `summary/patching.json`, `raw/cbs/CBS.log`, `raw/eventlogs/Setup.evtx`.
- "Is this thing rebooting?" -> `summary/events_summary.json` -> System channel -> `boot_markers` (never truncated).
- "Is anything pending a reboot?" -> `summary/patching.json` -> `pending_reboot` block.
- "What roles or apps are installed?" -> `summary/roles_apps.json`.
- "What does the host think its time is?" -> `summary/ad_context.json` -> `w32tm_status`.
- "Are any drivers stale or third-party?" -> `summary/drivers.json` -> `pnputil_drivers` (DriverStore packages with provider/class/date), `signed_drivers` (currently bound drivers), and `kernel_drivers` (all kernel-mode + FS drivers with state). Filter `pnputil_drivers` by `driver_date` for staleness, by `signer` for unsigned/third-party, by `class_guid` for boot-critical classes (Firmware `f2e7dd72-...`, Storage controllers `4d36e97b-...`, Network adapters `4d36e972-...`). Filter `kernel_drivers` by `driver_type='File System'` AND `state='Running'` for loaded filter drivers (AV/EDR/backup minifilters). Cross-reference with `raw/drivers/fltmc_filters.txt` for altitude (AV/EDR usually 300000-330000, backup 180000-190000).
- "Is the system drive too full to install patches?" -> `summary/storage.json` -> `update_readiness` (`system_free_gb`, `wu_threshold_gb`, `wu_blocked_by_free_space`, `low_space_volumes`).
- "How does this volume actually live on disk?" -> `summary/storage.json` -> `disks[*].partitions[*]` (disk -> partition -> volume traversal, including dynamic disks and storage spaces in `virtual_disks` / `storage_pools`).
- "Why is this box not getting patches from WSUS?" -> `summary/patching.json` -> `wu_client_state` (`flags.scan_stale`, `flags.install_stale`, `flags.download_stuck_likely`, `flags.wsus_reporting_stale`, plus per-field ages and `install_path` of `wua_direct` / `wsus_or_sccm` / `unknown`) and `wsus_check.verdict` (`wsus_responding`, `tcp_blocked`, `http_ok_but_not_wsus`, `http_error`, `no_wsus_configured`, `skipped_by_parameter`). The probe hits the WUA-canonical client endpoint `ClientWebService/Client.asmx?WSDL` plus `SelfUpdate/wuident.cab`.
- "Is Secure Boot on, and is this UEFI or BIOS?" -> `summary/inventory.json` -> `firmware_type` (`UEFI`, `BIOS`, or `unknown`) and `secure_boot` (`enabled`, `disabled`, `not_applicable`, `requires_elevation`, `unknown`). On UEFI without elevation the collector falls back to reading `HKLM:\System\CurrentControlSet\Control\SecureBoot\State\UEFISecureBootEnabled`.

## Severity vocabulary (`manifest.collection_errors[].severity`)

- `info` -- not applicable on this host (channel absent, role absent, key
  absent, collector skipped). Not a failure; just context.
- `warning` -- collector produced reduced output. Inspect what it did
  return.
- `error` -- collector produced no output for its category. Treat the
  category as missing.

## Drill-down recipes

Some artifacts are binary or otherwise opaque. The summary will point at
them; here is how to read them.

### EVTX (`raw/eventlogs/*.evtx`)

```
# Full text of every record matching an EventID
wevtutil qe raw\eventlogs\System.evtx /lf:true /q:"*[System[EventID=7031]]" /f:text

# Same in PowerShell
Get-WinEvent -Path raw\eventlogs\System.evtx -FilterXPath "*[System[EventID=7031]]" |
    Select-Object TimeCreated, Id, ProviderName, Message
```

### Performance counters (`raw/perf/snapshot.blg`)

```
Import-Counter -Path raw\perf\snapshot.blg |
    Select-Object -ExpandProperty CounterSamples |
    Where-Object Path -like '*Processor*' |
    Format-Table Timestamp, Path, CookedValue
```

### Windows Update ETL (`raw/windowsupdate/*.etl`)

```
Get-WindowsUpdateLog -ETLPath raw\windowsupdate -LogPath WindowsUpdate.log
# then read WindowsUpdate.log as plain text
```

### WUA reporting events (`raw/windowsupdate/ReportingEvents.log`)

Plain text. Each line is one event WUA tried to send to WSUS. Recent
"AU successfully reported event" lines mean the box is checking in;
"AU failed to report" means it is not. The artifact is the last 1MB
when the source file is oversize.

### WER reports (`raw/wer/reports/<report_dirname>/`)

Each report directory holds the per-crash artifacts WER produced. The text
manifest is `Report.wer` -- plain text, open with any editor; key fields:

```
EventName=AppHang | AppCrash | Critical
AppName=...
AppVersion=...
ModuleName=...
```

If a `.cab` is present, expand it for the embedded minidump and additional
metadata:

```
expand.exe -F:* raw\wer\reports\<dirname>\Report.cab .\extracted\
```

Hosts that have WER consent locked down (`DontShowUI` /
`DontSendAdditionalData`) typically produce only the `Report.wer` manifest --
no cab. The manifest alone is still enough to identify which faulting module
crashed and when.

### Registry exports (`raw/registry/*.reg`)

Plain text but UTF-16 LE with BOM (reg.exe writes that format). Open with
any editor; a grep of the key path locates the value.

### Minidumps (`raw/dumps/*.dmp`)

Open in WinDbg or `dotnet-dump analyze`. The bundle does not include
symbols; the consumer needs the public symbol server (or a private one for
non-Microsoft binaries).

### SQL self-dumps (`raw/role_specific/sql_dumps/<instance>/SQLDump<NNNN>.*`)

When SQL Server hits an in-process exception it drops three companions in
its LOG dir: `SQLDump<NNNN>.mdmp` (binary minidump), `SQLDump<NNNN>.txt`
(plain-text stack and short-stack signatures), and `SQLDump<NNNN>.log`
(additional log). The `.txt` is the easiest first read; it carries:

```
This file is generated by Microsoft SQL Server ...
... ExceptionAddress, ExceptionCode, FaultingInstruction, etc.
... Short Stack Dump
... module!function frames
```

Match the `<NNNN>` against the matching `Critical_sqlservr.exe` Report.wer
under `raw/wer/reports/` for the WER side of the same crash. Open the
`.mdmp` in WinDbg with the SQL public symbols if a deeper view is needed.

## Known caveats

- `manifest.size_budget.zip_compressed_bytes` is always `0` inside the
  bundle. The bundle is sealed before the ZIP exists. The real compressed
  size is whatever this ZIP file is on disk.
- `manifest.redactions_applied: []` means "no redaction patterns matched
  in the four scanned files", not "redaction was disabled". Redaction is
  always on; the scan list is intentionally narrow.
- `manifest.time_window.perf_from_utc` and `perf_to_utc` are present only
  when the Performance collector ran successfully.
- `manifest.baseline.available = false` is the default state for hosts
  with no baseline ever captured. Not an error.
- Empty `raw/` subdirectories are normal -- the collector creates the
  layout up front and leaves the directory if its collector found no
  eligible content (no dumps, no GPO output under non-elevated runs, etc.).
- `transcript/collector.log` is line-delimited JSON, one entry per event,
  not pretty-printed JSON. Parse line-by-line.
- `manifest.collection.elevation = User` means several collectors degraded:
  `gpresult` produces no file, some service state is unreadable, dcdiag
  and certain registry exports are absent. Plan re-collection under
  Administrator or SYSTEM if a category came back empty.
